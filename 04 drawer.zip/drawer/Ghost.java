/* Code for Week 3
 * Name:Karsten
 */

import ecs100.*;
import java.util.*;
import java.io.*;
import java.awt.Color;

/** Draws little pictures on the graphics pane
 */
public class Ghost{

    public static final String BLINKY = "Ghost";
    public static final String PINKY = "Pinky";
    public static final String INKY = "Inky";
    public static final String POKEY = "Pokey";

    public static final String UP = "UP";
    public static final String DOWN = "DOWN";
    public static final String LEFT = "LEFT";
    public static final String RIGHT = "RIGHT";
    public static final String STRAIGHT = "STRAIGHT";

    public void drawGhost(double x, double y, double wd, double ht, String name, String direction) {
        this.drawGhost(x, y, wd, ht, false, name, direction);
    }

    public void drawGhost(double x, double y, double wd, double ht, boolean scared, String name, String direction) {
        double left = x; 
        double topRect = y - ht;
        double topOval = topRect-wd/2;

        double yCurtainOval = y - (wd/2)/4;
        double curtainSize = wd/4;

        double eyeSize = wd/4;
        double yEye = topRect;
        double eyeDistanceFromSide = wd/8;
        double xLeftEye = left+eyeDistanceFromSide;
        double xRightEye = left+wd-eyeDistanceFromSide-eyeSize;

        //Pupli size and y position
        double pupilSize = wd/8;
        double yPupil = y-ht + pupilSize/2;

        //Declare  x positions (set impossible value to check later)
        double xLeftPupil = -100;
        double xRightPupil = -100;

        //Calculate the pupil's position
        if(direction.equals(RIGHT)) {
            xLeftPupil = xLeftEye + eyeSize - pupilSize;
            xRightPupil = xRightEye + eyeSize - pupilSize;
        } else if(direction.equals(UP)) {
            yPupil = topRect;
            xLeftPupil = xLeftEye + eyeSize/2 - pupilSize/2;
            xRightPupil = xRightEye + eyeSize/2 - pupilSize/2;
        } else if(direction.equals(STRAIGHT)) {
            yPupil = topRect + eyeSize/2 - pupilSize/2;
            xLeftPupil = xLeftEye + eyeSize/2 - pupilSize/2;
            xRightPupil = xRightEye + eyeSize/2 - pupilSize/2;
        } else if(direction.equals(DOWN)) {
            yPupil = topRect + eyeSize - pupilSize;
            xLeftPupil = xLeftEye + eyeSize/2 - pupilSize/2;
            xRightPupil = xRightEye + eyeSize/2 - pupilSize/2;
        } else if(direction.equals(LEFT)) {
            xLeftPupil = xLeftEye;
            xRightPupil = xRightEye;
        }

        //Invalid ghost type!
        if(xLeftPupil == -100) {
            //this will work for now. Later we will teach a better way using exceptions
            UI.println("UNKNOWN GHOST ERROR");
            return; 
        }

        //Ghosts's body
        if(scared) {
            UI.setColor(Color.BLUE);
        } else {
            if(name.equals(BLINKY)) {
                UI.setColor(Color.red);
            } else if(name.equals(PINKY)) {
                UI.setColor(Color.PINK);
            } else if(name.equals(INKY)) {
                UI.setColor(Color.BLUE);
            } else {
                UI.setColor(Color.YELLOW);
            }                
        }

        //Ghost's body and head
        UI.fillOval(left, topOval, wd, wd);
        UI.fillRect(left, topRect, wd, ht);

        //Ghost's "curtain"
        int i = 0;
        while(i<4) {
            UI.fillOval(left+curtainSize*i, yCurtainOval, curtainSize, curtainSize);
            i = i+1;
        
        }
        /*
        for(int i = 0; i<4; i++) {
        UI.fillOval(left+curtainSize*i, yCurtainOval, curtainSize, curtainSize);
        }
         */
        //Ghost's eyes
        UI.setColor(Color.white);
        UI.fillOval(xLeftEye, yEye, eyeSize, eyeSize);
        UI.fillOval(xRightEye, yEye, eyeSize, eyeSize);

        //Ghost's pupils
        UI.setColor(Color.black);
        UI.fillOval(xLeftPupil, yPupil, pupilSize, pupilSize);
        UI.fillOval(xRightPupil,yPupil, pupilSize, pupilSize);
    }

    public void clear(){
        UI.initialise();
        UI.clearGraphics();
    }

    public void drawBlinky(double x, double y, double wd, double ht, boolean scared, String direction) {
        drawGhost(x,y,wd,ht,false,BLINKY,direction);
    }

    public void drawGhost() {
        this.drawGhost(100, 100, 50, 50, false, PINKY, LEFT);
    }

}
